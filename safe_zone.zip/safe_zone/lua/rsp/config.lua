RSP.Data = {}


RSP:AddNewZone( "rp_bangclaw", {
	Center = Vector( -1431, -1178, 128 ),
	SizeBackwards = Vector( -250, -200, 65 ),
	SizeForwards = Vector( -150, -200, 180 )
} )

--[[
	RSP:AddNewZone( MAP, {
		Center = CENTER OF BOX,
		SizeBackwards = SIZE, GOING BACKWARDS,
		SizeForwards = SIZE, GOING FORWARDS
	} )
]]