﻿
surface.CreateFont( "SafeZoneBig", {
	font = "Trebuchet MS",
	size = 35,
	weight = 400,
	antialias = true,
} )

surface.CreateFont( "SafeZoneSmall", {
	font = "Trebuchet MS",
	size = 25,
	weight = 400,
	antialias = true,
} )

concommand.Add( "rsp_view_all", function()
	hook.Add( "PostDrawOpaqueRenderables", "rspRenderZones", function()
		for k,v in pairs( RSP.Data ) do
			render.DrawWireframeBox( v.Center, Angle( 0, 0, 0 ), v.SizeBackwards, v.SizeForwards, color_white, true )
		end
	end )
end )

timer.Create( "rsp_manage", 1, 0, function()
	if ( !IsValid( LocalPlayer() ) or !LocalPlayer().GetPos ) then return end
	
	RSP.DrawHUD = RSP:InsideSafeZone( LocalPlayer():GetPos() )
end )

hook.Add( "HUDPaint", "rsp_draw_safezone", function()
	if ( !RSP.DrawHUD ) then return end
	
	local w = ScrW()
	local h = ScrH()
	
	draw.SimpleTextOutlined( "Безопасная зона", "SafeZoneBig", w/2, 60, Color( 50, 220, 50 ), 1, 1, 2, color_black )
	draw.SimpleTextOutlined( "Вам не наносится урон ", "SafeZoneSmall", w/2, 90, Color( 220, 220, 220 ), 1, 1, 1, color_black )
end )